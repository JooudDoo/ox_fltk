README.lib
----------

This README file is a placeholder for library files on your
system.

Under Microsoft Windows a successful build of all projects and
configurations will contain debug and release libraries for you
to link to - all are built using the multi-threaded DLL
settings.  The DLL files (fltkdll.dll and fltkdlld.dll) required
for a complete DLL-based binary distribution are located in the
"visualc" directory.

Under UNIX a single set of library files will be built, with or
without debug information depending on the options you provided
to the configure script.
